# Samling Customer Panel Handover (2026-03-27)

## Scope
This handover contains customer-panel and messaging updates completed on 2026-03-27.

## Important
- Website default language is Norwegian.
- Google Translate supports switching between Norwegian and English.
- Keep security fix in the message-reply endpoint.

## Production Files Changed
- app/Http/Controllers/Front/UserController.php
- public/front/js/custom.js
- resources/views/front/layout/header.blade.php
- resources/views/front/layout/scripts.blade.php
- resources/views/front/users/load_enquiries.blade.php
- resources/views/front/users/enquiries.blade.php
- resources/views/front/users/enquiries_detail.blade.php
- resources/views/front/users/partials/sidebar.blade.php

## Local/Dev Files (Do Not Deploy)
- start-local.bat
- scripts/start-local.ps1
- scripts/stop-local.ps1
- LOCALHOST_SETUP.md
- .env

## Key Functional Changes
1. Messaging behavior
- Assignment rows and direct rows now open normal supplier conversation pages.
- Message polling and send flow remain active.
- Assignment info modal still available from info button.

2. Security hardening
- Message reply endpoint validates that enquiry_id belongs to the authenticated customer before saving reply.
- Unauthorized access returns 403 (Not allowed).

3. UI and language
- Customer-facing website text remains Norwegian by default.
- Internal cleanup retained where code was unused or redundant.

4. Translation widget fix
- Google Translate initialization updated to keep Norwegian available as default language option.
- Switching to English no longer removes Norwegian from selector state.

## Validation Checklist
Run these checks after deployment:
1. Customer panel navigation
- Profile, Messages, Favorites, and Create Assignment are visible in Norwegian.

2. Messaging list
- Filters show Norwegian labels.
- Opening assignment/direct conversation works.
- Status toggle labels show Aktiv/Avsluttet.

3. Conversation detail
- User can send message and optional images.
- Polling fetches new vendor messages.

4. Security
- Verify one customer cannot post replies to another customer enquiry_id.

5. Translate
- Language selector is visible.
- English can be selected.
- Norwegian remains selectable afterward.

## Suggested PR Title
Customer Panel + Messaging Stabilization + Translate Selector Fix + Reply Authorization Check

## Suggested PR Description
### Summary
- Stabilized customer panel messaging and conversation views.
- Preserved Norwegian as default customer-facing language.
- Fixed Google Translate selector behavior (Norwegian remains available after language switch).
- Added ownership validation in reply endpoint to prevent posting to foreign enquiry_id.

### Risk
- Low to medium: touches controller logic and multiple Blade/JS files.
- Security change is required and should not be reverted.

### QA
- Verify messaging flow, assignment info modal, panel labels, and translate selector behavior.

## Rollback Plan
- Revert the listed production files as one rollback patch if regressions are detected.
- Keep a separate patch for security validation if full rollback is required.
