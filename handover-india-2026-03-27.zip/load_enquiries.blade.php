<?php
use App\Models\Enquiry;
use App\Models\EnquiriesResponse;
?>
<style>
   .message-hub {
      border: 1px solid #e8d9c4;
      border-radius: 14px;
      background: #fff;
      overflow: hidden;
   }
   .message-filters {
      padding: 12px 16px;
      border-bottom: 1px solid #f1e6d5;
      background: #fffcf8;
   }
   .message-filter-grid {
      display: grid;
      grid-template-columns: repeat(3, minmax(0, 1fr));
      gap: 10px;
   }
   .message-filter label {
      display: block;
      margin: 0 0 4px;
      font-size: 11px;
      font-weight: 700;
      letter-spacing: 0.3px;
      text-transform: uppercase;
      color: #7a6752;
   }
   .seluserenquiries {
      width: 100%;
      height: 38px;
      border: 1px solid #dbc4a3;
      border-radius: 8px;
      background: #fff;
      padding: 6px 10px;
      font-size: 13px;
      color: #3a3023;
   }
   .message-list {
      padding: 12px;
      display: grid;
      gap: 10px;
   }
   .message-item {
      border: 1px solid #ecdcc7;
      border-radius: 12px;
      background: #fff;
      padding: 12px;
      box-shadow: 0 8px 18px rgba(58, 43, 20, 0.06);
      display: grid;
      grid-template-columns: minmax(220px, 1.5fr) minmax(140px, 0.9fr) minmax(260px, 1.5fr) minmax(200px, 1fr);
      gap: 10px;
      align-items: center;
   }
   .message-vendor-title {
      margin: 0;
      font-size: 17px;
      line-height: 1.2;
   }
   .message-vendor-title a {
      color: #2f2516;
      text-decoration: underline;
      font-weight: 700;
   }
   .message-vendor-meta {
      margin-top: 4px;
      color: #7a6853;
      font-size: 12px;
   }
   .message-type-cell {
      display: flex;
      align-items: center;
      gap: 8px;
      flex-wrap: wrap;
   }
   .type-chip {
      display: inline-flex;
      align-items: center;
      border-radius: 999px;
      font-size: 11px;
      font-weight: 700;
      padding: 5px 11px;
      border: 1px solid transparent;
   }
   .type-chip.assignment {
      background: #eaf2ff;
      color: #285fae;
      border-color: #bdd4f5;
   }
   .type-chip.direct {
      background: #f3f3f3;
      color: #666;
      border-color: #d4d4d4;
   }
   .message-type-note {
      font-size: 12px;
      color: #746351;
   }
   .message-unread {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      margin-left: 6px;
      min-width: 20px;
      height: 20px;
      border-radius: 999px;
      background: #e78002;
      color: #fff;
      font-size: 11px;
      font-weight: 700;
      border: 1px solid #fff;
   }
   .message-date {
      font-size: 13px;
      color: #594937;
      font-weight: 700;
   }
   .message-category {
      margin-top: 4px;
      font-size: 12px;
      color: #7a6752;
   }
   .message-actions {
      display: flex;
      gap: 8px;
      align-items: center;
      flex-wrap: wrap;
      justify-content: flex-start;
      margin-bottom: 8px;
   }
   .message-action-btn {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      width: 36px;
      height: 36px;
      border-radius: 10px;
      color: #fff !important;
      font-size: 14px;
      transition: transform 0.16s ease, opacity 0.16s ease;
      text-decoration: none !important;
   }
   .message-action-btn.info {
      background: #5e7085;
   }
   .message-action-btn.open {
      background: #7c66b4;
   }
   .message-action-btn:hover {
      transform: translateY(-1px);
      opacity: 0.95;
   }
   .message-open-link {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      min-height: 36px;
      border-radius: 10px;
      padding: 7px 12px;
      font-size: 12px;
      font-weight: 700;
      text-decoration: none !important;
      color: #fff !important;
      transition: transform 0.16s ease, opacity 0.16s ease;
   }
   .message-open-link.assignment { background: #2f6fbe; border: 1px solid #2f6fbe; }
   .message-open-link.direct { background: #7c66b4; border: 1px solid #7c66b4; }
   .message-open-link:hover {
      transform: translateY(-1px);
      opacity: 0.95;
   }
   .status-marker {
      display: none;
   }
   .message-toggles {
      display: flex;
      gap: 8px;
      flex-wrap: wrap;
   }
   .toggle-chip {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      gap: 6px;
      min-width: 110px;
      padding: 7px 11px;
      border-radius: 999px;
      font-size: 12px;
      font-weight: 700;
      border: 1px solid transparent;
      transition: transform 0.16s ease, opacity 0.16s ease;
   }
   .toggle-chip.is-open {
      background: #eaf8ef;
      color: #1f6f39;
      border-color: #97d4aa;
   }
   .toggle-chip.is-closed {
      background: #f5f5f5;
      color: #666;
      border-color: #d2d2d2;
   }
   .updateEnquiryStatus {
      text-decoration: none !important;
   }
   .updateEnquiryStatus:hover .toggle-chip {
      transform: translateY(-1px);
      opacity: 0.95;
   }
   .message-empty {
      border: 1px dashed #dcc5a4;
      border-radius: 10px;
      padding: 26px;
      text-align: center;
      color: #746652;
      background: #fffaf3;
      font-size: 14px;
   }
   @media (max-width: 1199px) {
      .message-item {
         grid-template-columns: 1fr;
      }
   }
   @media (max-width: 767px) {
      .message-filter-grid {
         grid-template-columns: 1fr;
      }
   }
</style>

<div class="message-hub">
   <div class="message-filters">
      <div class="message-filter-grid">
         <div class="message-filter">
            <label for="seltypeenq">Meldingstype</label>
            <select id="seltypeenq" class="seluserenquiries">
               <option value="">Alle</option>
               <option value="assignment" @if(isset($message_type) && $message_type=="assignment") selected @endif>Oppdrag</option>
               <option value="direct" @if(isset($message_type) && $message_type=="direct") selected @endif>Direkte</option>
            </select>
         </div>
         <div class="message-filter">
            <label for="selcatenq">Kategori</label>
            <select id="selcatenq" class="seluserenquiries">
               <option value="">Alle kategorier</option>
               @foreach($allcategories as $cat)
                  <option value="{{ $cat }}" @if(isset($enqCat) && $enqCat==$cat) selected @endif>{{ $cat }}</option>
               @endforeach
            </select>
         </div>
         <div class="message-filter">
            <label for="selcloseenq">Status</label>
            <select id="selcloseenq" class="seluserenquiries">
               <option value="">Alle</option>
               <option value="1" @if(isset($active_close) && $active_close=="1") selected @endif>Aktiv</option>
               <option value="0" @if(isset($active_close) && $active_close=="0") selected @endif>Avsluttet</option>
            </select>
         </div>
      </div>
   </div>

   <div class="message-list">
      @forelse($enquiries as $key => $enquiry)
         @if(!isset($enquiry['product']['category']['category_name']))
            @continue
         @endif
         @php
            $messageType = $enquiry['messageType'] ?? 'Direkte';
            $isAssignment = $messageType === 'Oppdrag';
            $lastEnquiryDate = EnquiriesResponse::getlastEnquiryDate($enquiry['id']);
            $displayDate = $lastEnquiryDate != '' ? date('d.m.y, H:i', strtotime($lastEnquiryDate)) : date('d.m.y, H:i', strtotime($enquiry['created_at']));
            $conversationUrl = url('user/enquiries/'.$enquiry['id']);
         @endphp

         <div class="message-item">
            <div>
               <h5 class="message-vendor-title">
                  @if(isset($enquiry['product']['product_name']))
                     <a href="{{ $conversationUrl }}">{{ $enquiry['product']['product_name'] }}</a>
                     @if(!empty($enquiry['unreadCount']) && (int)$enquiry['unreadCount'] > 0)
                        <span class="message-unread">{{ (int)$enquiry['unreadCount'] }}</span>
                     @endif
                  @else
                     Ukjent leverandor
                  @endif
               </h5>
               <div class="message-vendor-meta">Kategori: {{ $enquiry['product']['category']['category_name'] }}</div>
            </div>

            <div>
               <div class="message-date">{{ $displayDate }}</div>
               <div class="message-category">Siste aktivitet</div>
            </div>

            <div class="message-type-cell">
               @if($isAssignment)
                  <span class="type-chip assignment">Oppdrag</span>
                  <span class="message-type-note">Mottatt fra leverandor pa oppdraget ditt</span>
               @else
                  <span class="type-chip direct">Direkte</span>
                  <span class="message-type-note">Direkte melding du startet med leverandor</span>
               @endif
            </div>

            <div>
               <div class="message-actions">
                  @if($isAssignment && !empty($enquiry['enquiry_detail_id']))
                     @php $enquiryDetails = Enquiry::enquiryDetails($enquiry['enquiry_detail_id']); @endphp
                     <a href="javascript:void(0)" class="message-action-btn info" data-toggle="modal" data-target="#replymodal{{$key}}" title="Se oppdragsinfo">
                        <i class="fa fa-info" aria-hidden="true"></i>
                     </a>
                     <div class="modal replymodal fade" id="replymodal{{$key}}" tabindex="-1" role="dialog" aria-hidden="true">
                        <div class="modal-dialog">
                           <div class="modal-content">
                              <div class="modal-header">
                                 <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">×</span></button>
                                 <h4>Oppdragsinfo</h4>
                              </div>
                              <div class="modal-body">
                                 <div class="inquery-info-area">
                                    <table class="table info-pop-table">
                                       <tr class="firt-row"><td class="border-zero"><b>Tittel</b></td><td class="border-zero">{{ $enquiryDetails['title'] }}</td></tr>
                                       <tr><td><b>Navn</b></td><td>{{ $enquiryDetails['name'] }}</td></tr>
                                       <tr><td><b>Adresse</b></td><td>{{ $enquiryDetails['address'] }}</td></tr>
                                       <tr><td><b>By</b></td><td>{{ $enquiryDetails['city'] }}</td></tr>
                                       <tr><td><b>Pinkode</b></td><td>{{ $enquiryDetails['pincode'] }}</td></tr>
                                       @if($enquiryDetails['desired_price'] > 0)
                                          <tr><td><b>Onsket pris</b></td><td>{{ $enquiryDetails['desired_price'] }}</td></tr>
                                       @endif
                                       @if(isset($enquiryDetails['assignment_date']) && !empty($enquiryDetails['assignment_date']))
                                          <tr><td><b>Oppdragsdato</b></td><td>{{ $enquiryDetails['assignment_date'] }}</td></tr>
                                       @endif
                                    </table>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  @endif

                  @if($isAssignment)
                     <a class="message-open-link assignment" href="{{ $conversationUrl }}">Apne oppdrag</a>
                  @else
                     <a class="message-open-link direct" href="{{ $conversationUrl }}">Apne melding</a>
                  @endif
               </div>

               <div class="message-toggles">
                  @if($enquiry['status'] == 1)
                     <a class="updateEnquiryStatus" id="enquiry-{{ $enquiry['id'] }}" enquiry_id="{{ $enquiry['id'] }}" href="javascript:void(0)"><i class="status-marker" status="Active"></i><span class="toggle-chip is-open"><i class="fa fa-toggle-on"></i> Aktiv</span></a>
                  @else
                     <a class="updateEnquiryStatus" id="enquiry-{{ $enquiry['id'] }}" enquiry_id="{{ $enquiry['id'] }}" href="javascript:void(0)"><i class="status-marker" status="Inactive"></i><span class="toggle-chip is-closed"><i class="fa fa-toggle-off"></i> Avsluttet</span></a>
                  @endif
               </div>
            </div>
         </div>
      @empty
         <div class="message-empty">Ingen meldinger funnet med valgt filter.</div>
      @endforelse
   </div>
</div>
                           