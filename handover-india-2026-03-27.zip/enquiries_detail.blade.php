<?php 
$messagesCountCustomer = messagesCountCustomer();
?>
@extends('front.layout.layout')
@section('content')
<style>
   .modal-backdrop {
      z-index: 999;
   }
   .conversation-shell {
      background: #f8f4ed;
      border: 1px solid #ecd9bf;
      border-radius: 14px;
      padding: 14px;
      margin-top: 12px;
   }
   .conversation-card {
      background: #fff;
      border-radius: 12px;
      border: 1px solid #efe1ce;
      box-shadow: 0 12px 28px rgba(67, 47, 20, 0.08);
      overflow: hidden;
   }
   .conversation-head {
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 12px;
      border-bottom: 1px solid #f0e4d3;
      background: linear-gradient(120deg, #fff6e8, #fff);
      padding: 16px 18px;
   }
   .conversation-title {
      margin: 0;
      font-size: 20px;
      font-weight: 700;
      color: #2f2516;
   }
   .conversation-title a {
      color: #c96900;
      text-decoration: underline;
   }
   .conversation-actions {
      display: flex;
      gap: 8px;
   }
   .reply-back-btn,
   .reply-ref-btn {
      border-radius: 8px;
      font-weight: 600;
      transition: transform 0.2s ease, opacity 0.2s ease;
   }
   .reply-back-btn:hover,
   .reply-ref-btn:hover {
      transform: translateY(-1px);
      opacity: 0.95;
   }
   .chat-area-sec.enquiries-reply-area {
      background-color: #fcf8f2;
      padding: 18px;
      margin-top: 0;
      max-height: 62vh;
      overflow-y: auto;
   }
   .chat-row {
      margin: 0 0 8px;
   }
   .customermsg,
   .vendormsg {
      width: 78%;
      border-radius: 12px;
      box-shadow: 0 7px 18px rgba(57, 42, 22, 0.08);
      padding: 14px 16px;
      margin-bottom: 0;
      position: relative;
   }
   .customermsg {
      margin-left: auto;
      background: #f7ecff;
      border: 1px solid #e8d4ff;
      border-bottom-right-radius: 6px;
   }
   .vendormsg {
      background: #fff;
      border: 1px solid #e6dccf;
      border-bottom-left-radius: 6px;
   }
   .message-author {
      display: block;
      font-size: 12px;
      font-weight: 700;
      margin-bottom: 8px;
      color: #7f6543;
      text-transform: uppercase;
      letter-spacing: 0.4px;
   }
   .customermsg .message-author {
      color: #c96900;
   }
   .msg-reply-img {
      max-width: 130px !important;
      border-radius: 8px;
      border: 1px solid #dfd1bf;
      margin-top: 6px;
      margin-bottom: 6px;
   }
   .composer-wrap {
      border-top: 1px solid #f0e4d3;
      background: #fff;
      padding: 14px 16px;
   }
   .composer-wrap textarea {
      width: 100%;
      min-height: 74px;
      border: 1px solid #d9c3a2;
      border-radius: 8px;
      padding: 10px 12px;
      resize: vertical;
   }
   .composer-wrap textarea:focus {
      outline: none;
      border-color: #d9851f;
      box-shadow: 0 0 0 3px rgba(217, 133, 31, 0.15);
   }
   .composer-row {
      margin-top: 10px;
      display: flex;
      flex-wrap: wrap;
      align-items: center;
      gap: 10px;
      justify-content: space-between;
   }
   .upload-file-area {
      margin: 0;
      width: auto;
      max-width: 100%;
      display: inline-block !important;
   }
   .send-reply .r-btn {
      margin-left: 0;
      border-radius: 8px;
      font-weight: 700;
      min-width: 110px;
      width: auto !important;
      height: 40px;
      padding: 0 16px;
      display: inline-flex;
      align-items: center;
      justify-content: center;
   }
   @media (max-width: 767px) {
      .conversation-shell {
         padding: 10px;
      }
      .conversation-head {
         align-items: flex-start;
         flex-direction: column;
      }
      .customermsg,
      .vendormsg {
         width: 86%;
         padding: 10px 12px;
         box-shadow: 0 5px 12px rgba(57, 42, 22, 0.07);
      }
      .message-author {
         font-size: 11px;
         margin-bottom: 6px;
      }
      .enquery-msg {
         font-size: 14px;
         line-height: 1.35;
      }
      .chat-dtime {
         display: block;
         margin-top: 6px;
         text-align: right;
         font-size: 11px;
         color: #8b7b66;
      }
      .chat-area-sec.enquiries-reply-area {
         max-height: 56vh;
         padding: 10px;
      }
      .composer-wrap {
         padding: 10px;
      }
      .composer-wrap textarea {
         min-height: 56px;
         font-size: 14px;
      }
      .composer-row {
         margin-top: 8px;
         gap: 8px;
         justify-content: space-between;
      }
      .upload-file-area {
         max-width: calc(100% - 120px);
         font-size: 12px;
      }
      .send-reply .r-btn {
         min-width: 96px;
         height: 38px;
      }
   }
</style>

<div class="page-wrapper">
   <div class="contact-section account-page">
      <div class="auto-container">
         <div class="row clearfix">
            <div class="col-md-3 col-sm-3 col-xs-12 column account-tab-area">
               @include('front.users.partials.sidebar', ['activeTab' => 'enquiries'])
            </div>
            <!--Content Side-->
            <div class="col-md-9 col-sm-9 col-xs-12 column pull-left">
               <div class="conversation-shell">
               <div class="conversation-card">
               <div class="sec-title account-heading reply-table-section">
                  @if(Session::has('success_message'))
                  <div class="alert alert-success alert-dismissible fade in" role="alert" style="margin-top:20px;">
                     <strong>Success: </strong> {{ Session::get('success_message')}}
                     <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                     <span aria-hidden="true">&times;</span>
                     </button>
                  </div>
                  @endif
                  @if(Session::has('error_message'))
                  <div class="alert alert-danger alert-dismissible fade in" role="alert">
                    <span style="font-weight: bold; float:left;"> </span> {{ $errors->response->first('message') }}<br>
                  {{ $errors->response->first('image') }}
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                      <span aria-hidden="true">&times;</span>
                    </button>
                  </div>
                @endif
                @if(count($errors) > 0 )
                  <div class="alert alert-danger alert-dismissible fade in" role="alert" style="margin-top:20px;">
                      <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                          <span aria-hidden="true">&times;</span>
                      </button>
                      <ul class="p-0 m-0" style="list-style: none;">
                          @foreach($errors->all() as $error)
                          <li>{{$error}}</li>
                          @endforeach
                      </ul>
                  </div>
               @endif
                <div class="conversation-head">
                   <div>
                      <h3 class="conversation-title">{{ $conversationTitle ?? 'Samtale' }}</h3>
                      <p style="margin:6px 0 0; font-size:12px; color:#746652;">Direkte melding mellom deg og leverandor.</p>
                   </div>
                   <div class="conversation-actions">
                      <a href="{{ url('user/enquiries/') }}" class="reply-back-btn">
                      <i class="fa fa-arrow-left" aria-hidden="true"></i> Tilbake
                      </a>
                   </div>
                </div>
               </div>
               <div class="chat-area-sec enquiries-reply-area">
                  @php $lastMessageId = count($enquiries)>0 ? (int)$enquiries[count($enquiries)-1]['id'] : 0; @endphp
                  <div id="chatMessages" data-last-id="{{ $lastMessageId }}">
                     @foreach($enquiries as $enquiry)
                        @include('front.users.partials.enquiry_message', ['enquiry' => $enquiry])
                     @endforeach
                  </div>
                  <div class="send-reply composer-wrap">
                     <div class="form-group">
                        <form id="replyEnquiryForm" method="post" action="{{ url('user/enquiry/response') }}" enctype="multipart/form-data">@csrf
                           <input type="hidden" name="enquiry_id" value="{{ $enquiry_id }}">
                           <textarea name="message" placeholder="Skriv melding til leverandoren" required></textarea>
                           <div class="composer-row">
                              <input class="upload-file-area" type="file" name="images[]" multiple>
                              <button type="submit" class="r-btn">Send</button>
                           </div>
                        </form>
                     </div>
                  </div>
               </div>
            </div>
            </div>
            </div>
         </div>
      </div>
   </div>
</div>
@endsection

@section('javascript')

<script>
    $(document).ready(function () {
      var enquiryId = "{{ $enquiry_id }}";
      var $chatContainer = $(".enquiries-reply-area");
      var $chatMessages = $("#chatMessages");
      var pollingTimer = null;
      var isSending = false;
      var lastMessageId = parseInt($chatMessages.data("last-id"), 10) || 0;

      function scrollChatToBottom(force) {
         if (!$chatContainer.length) {
            return;
         }

         var container = $chatContainer[0];
         var distanceFromBottom = container.scrollHeight - (container.scrollTop + container.clientHeight);
         if (force || distanceFromBottom < 140) {
            container.scrollTop = container.scrollHeight;
         }
      }

      function appendNewMessages(html, nextLastId) {
         if (html && html.trim() !== "") {
            $chatMessages.append(html);
            scrollChatToBottom(false);
         }
         if (nextLastId) {
            lastMessageId = parseInt(nextLastId, 10) || lastMessageId;
            $chatMessages.attr("data-last-id", lastMessageId);
         }
      }

      function pollNewMessages(forceScroll) {
         $.ajax({
            url: "/user/enquiries/" + enquiryId + "/messages",
            type: "GET",
            dataType: "json",
            data: { after_id: lastMessageId },
            success: function (resp) {
               if (resp && resp.status) {
                  appendNewMessages(resp.message_html || "", resp.last_id || lastMessageId);
                  if (forceScroll) {
                     scrollChatToBottom(true);
                  }
               }
            }
         });
      }

      scrollChatToBottom(true);

      pollingTimer = setInterval(function () {
         if (!isSending) {
            pollNewMessages(false);
         }
      }, 4000);

       $("#replyEnquiryForm").submit(function (event) {
           event.preventDefault(); // Prevent default form submission

           var form = $(this);
           var formData = new FormData(this);
           var submitBtn = form.find("button[type='submit']");
           isSending = true;
           submitBtn.prop("disabled", true).text("Sender...");

           $.ajax({
               url: form.attr("action"),
               type: form.attr("method"),
               data: formData,
               processData: false,
               contentType: false,
               dataType: "json",
               success: function (response) {
                  if (response && response.status) {
                     form[0].reset();
                     appendNewMessages(response.message_html || "", response.message_id || lastMessageId);
                     scrollChatToBottom(true);
                  }
               },
               error: function (xhr) {
                  var msg = "Noe gikk galt. Prove igjen.";
                  if (xhr.responseJSON && xhr.responseJSON.errors) {
                     var firstKey = Object.keys(xhr.responseJSON.errors)[0];
                     if (firstKey) {
                        msg = xhr.responseJSON.errors[firstKey][0];
                     }
                  }
                  alert(msg);
               },
               complete: function () {
                  isSending = false;
                  submitBtn.prop("disabled", false).text("Send");
               }
           });
       });

       $(window).on("beforeunload", function () {
         if (pollingTimer) {
            clearInterval(pollingTimer);
         }
       });
   });
</script>
@endsection         