@php
   $messagesCountCustomer = messagesCountCustomer();
   $activeTab = $activeTab ?? '';
   $panelBgColor = Auth::check() && !empty(Auth::user()->panel_bg_color) ? Auth::user()->panel_bg_color : '#f8f4ed';
   $panelAccentColor = Auth::check() && !empty(Auth::user()->panel_accent_color) ? Auth::user()->panel_accent_color : '#e78002';
@endphp

<style>
   :root {
      --customer-panel-bg: {{ $panelBgColor }};
      --customer-panel-accent: {{ $panelAccentColor }};
   }
   .customer-mobile-nav {
      display: none;
   }
   body,
   .page-wrapper,
   .contact-section.account-page {
      background: linear-gradient(155deg, rgba(255, 255, 255, 0.55), rgba(255, 255, 255, 0.08)), var(--customer-panel-bg) !important;
   }
   .customer-panel-shell,
   .messages-shell,
   .conversation-shell {
      background: linear-gradient(160deg, rgba(255, 255, 255, 0.46), rgba(255, 255, 255, 0.12)), var(--customer-panel-bg) !important;
      box-shadow: inset 0 1px 0 rgba(255, 255, 255, 0.68), 0 12px 30px rgba(64, 46, 22, 0.08);
   }
   .contact-section.account-page a,
   .contact-section.account-page .theme-link {
      color: var(--customer-panel-accent);
   }
   .save-btn,
   .favorite-link,
   .message-action-btn.open,
   .reply-back-btn,
   .send-reply .r-btn,
   .contact-section.account-page button[type="submit"],
   .contact-section.account-page .theme-btn,
   .contact-section.account-page .view-icon {
      background: linear-gradient(180deg, rgba(255, 255, 255, 0.32), rgba(255, 255, 255, 0.04)), var(--customer-panel-accent) !important;
      border-color: var(--customer-panel-accent) !important;
      color: #fff !important;
      box-shadow: inset 0 1px 0 rgba(255, 255, 255, 0.45), 0 8px 18px rgba(39, 31, 20, 0.15);
   }
   .contact-section.account-page .profile-form-shell input:focus,
   .contact-section.account-page .profile-form-shell textarea:focus,
   .contact-section.account-page .profile-form-shell select:focus {
      border-color: var(--customer-panel-accent) !important;
      box-shadow: 0 0 0 3px rgba(0, 0, 0, 0.08);
   }
   .contact-section.account-page .chip.reply,
   .contact-section.account-page .count-number {
      background-color: var(--customer-panel-accent) !important;
      border-color: var(--customer-panel-accent) !important;
      color: #fff !important;
   }
   .conversation-title a,
   .messages-panel-title,
   .customer-panel-header h3 {
      color: #2f2516;
   }
   .customer-panel-sidebar .account-sidebar li a.is-active,
   .customer-panel-sidebar .account-sidebar li a:hover {
      border-left: 3px solid var(--customer-panel-accent);
   }
   @media (max-width: 991px) {
      .customer-panel-shell,
      .messages-shell,
      .conversation-shell {
         border-radius: 16px;
         padding: 12px;
      }
      .customer-panel-main,
      .messages-panel,
      .conversation-card {
         border-radius: 14px;
      }
      .contact-section.account-page input,
      .contact-section.account-page select,
      .contact-section.account-page textarea,
      .contact-section.account-page button,
      .contact-section.account-page a {
         min-height: 42px;
      }
   }
   @media (max-width: 767px) {
      .contact-section.account-page {
         padding-bottom: calc(88px + env(safe-area-inset-bottom));
         -webkit-tap-highlight-color: rgba(0, 0, 0, 0.06);
      }
      .customer-panel-sidebar {
         display: none;
      }
      .customer-panel-shell,
      .messages-shell,
      .conversation-shell {
         padding: 10px;
         border-radius: 14px;
         margin-top: 8px;
      }
      .customer-panel-header,
      .messages-panel-head,
      .conversation-head {
         padding: 12px 12px;
      }
      .customer-panel-body,
      .messages-panel-body,
      .chat-area-sec.enquiries-reply-area {
         padding: 10px;
      }
      .customer-mobile-nav {
         position: fixed;
         left: 10px;
         right: 10px;
         bottom: calc(8px + env(safe-area-inset-bottom));
         z-index: 9999;
         border: 1px solid #dcc6a8;
         border-radius: 16px;
         background: rgba(255, 255, 255, 0.92);
         backdrop-filter: blur(12px);
         -webkit-backdrop-filter: blur(12px);
         box-shadow: 0 12px 26px rgba(48, 36, 18, 0.18);
         display: grid;
         grid-template-columns: repeat(4, minmax(0, 1fr));
         gap: 4px;
         padding: 6px;
      }
      .customer-mobile-nav a {
         position: relative;
         display: flex;
         flex-direction: column;
         align-items: center;
         justify-content: center;
         gap: 4px;
         min-height: 56px;
         border-radius: 12px;
         color: #5b4b37;
         text-decoration: none !important;
         font-size: 10px;
         font-weight: 700;
         line-height: 1.2;
         border: 1px solid transparent;
      }
      .customer-mobile-nav a i {
         font-size: 15px;
      }
      .customer-mobile-nav a.is-active {
         color: #fff !important;
         border-color: var(--customer-panel-accent);
         background: linear-gradient(180deg, rgba(255, 255, 255, 0.26), rgba(255, 255, 255, 0.02)), var(--customer-panel-accent);
      }
      .customer-mobile-nav .count-number {
         position: absolute;
         top: 4px;
         right: 12px;
         left: auto !important;
         width: 18px;
         height: 18px;
         line-height: 16px;
         font-size: 10px;
      }
   }
</style>

<div class="info-box p-xs-15 customer-panel-sidebar">
   <ul class="account-sidebar">
      <li>
         <a href="{{ url('user/account') }}" class="js-customer-tab-link {{ $activeTab === 'account' ? 'is-active' : '' }}">
            <span class="fa fa-user"></span>
            <p class="{{ $activeTab === 'account' ? 'active-list' : '' }}">Profil</p>
         </a>
      </li>
      <li>
         <a href="{{ url('user/enquiries') }}" class="js-customer-tab-link {{ $activeTab === 'enquiries' ? 'is-active' : '' }}">
            <span class="fa fa-comment"></span>
            <p class="{{ $activeTab === 'enquiries' ? 'active-list' : '' }}">
               @if(isset($messagesCountCustomer) && $messagesCountCustomer > 0)
                  <span class="count-number">{{ $messagesCountCustomer }}</span>
               @endif
               Meldinger
            </p>
         </a>
      </li>
      <li>
         <a href="{{ url('user/wishlist') }}" class="js-customer-tab-link {{ $activeTab === 'wishlist' ? 'is-active' : '' }}">
            <span class="fa fa-heart"></span>
            <p class="{{ $activeTab === 'wishlist' ? 'active-list' : '' }}">Favoritter</p>
         </a>
      </li>
      <li>
         <a href="{{ url('enquire-us') }}">
            <span class="fa fa-plus"></span>
            <p>Legg ut oppdrag</p>
         </a>
      </li>
   </ul>
</div>

<nav class="customer-mobile-nav">
   <a href="{{ url('user/account') }}" class="js-customer-tab-link {{ $activeTab === 'account' ? 'is-active' : '' }}">
      <i class="fa fa-user"></i>
      <span>Profil</span>
   </a>
   <a href="{{ url('user/enquiries') }}" class="js-customer-tab-link {{ $activeTab === 'enquiries' ? 'is-active' : '' }}">
      <i class="fa fa-comment"></i>
      @if(isset($messagesCountCustomer) && $messagesCountCustomer > 0)
         <span class="count-number">{{ $messagesCountCustomer }}</span>
      @endif
      <span>Meldinger</span>
   </a>
   <a href="{{ url('user/wishlist') }}" class="js-customer-tab-link {{ $activeTab === 'wishlist' ? 'is-active' : '' }}">
      <i class="fa fa-heart"></i>
      <span>Favoritter</span>
   </a>
   <a href="{{ url('enquire-us') }}">
      <i class="fa fa-plus"></i>
      <span>Oppdrag</span>
   </a>
</nav>
